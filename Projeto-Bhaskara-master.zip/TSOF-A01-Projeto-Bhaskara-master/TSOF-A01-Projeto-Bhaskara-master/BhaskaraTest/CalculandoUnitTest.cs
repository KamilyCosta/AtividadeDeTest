using BhaskaraApp;
using System.Drawing;
namespace BhaskaraTest
{
    [TestClass]
    public class CalculandoUnitTest
    {
        private Bhaskara bhaskara;

        [TestInitialize]
        public void Inicializar()
        {
          bhaskara = new Bhaskara(1, -3, 2);
        }

        [TestMethod]
        [DataRow( 1, -3, 2, 1)]
        [DataRow(1, -4, 3, 4)]
        [DataRow(3, -12, 12, 0)]
        [DataRow(1, 0, -4, 16)]

        public void TesteCalcularDelta(double a, double b, double c, double esperado)
        {
           bhaskara = new Bhaskara(a, b, c);
           double obtido = bhaskara.CalcularDelta();

           Assert.AreEqual(esperado, obtido);
        }

        [TestMethod]
        [DataRow(1, -3, 2, true)]
        [DataRow(1, -4, -5, true)]
        [DataRow(1, 2, 5, false)]
        [DataRow(1, -6 , 9, false)]
        public void TemRaizesReais(double a, double b, double c, bool esperado)
        {
            bhaskara = new Bhaskara(a, b, c);
            bool obtido = bhaskara.TemRaizesReais();
            Assert.AreEqual(esperado, obtido);
        }


        [TestMethod]
        [DataRow(1, -5, 6, 3.0, 2.0)]
        [DataRow(1.0, 0, -4.0, 2.0, -2.0)]
        [DataRow(0, 0, 0, null, null)]
        [DataRow(1, 0, -3, 1.732, -1.732)]
        public void TestarCalcularRaizes(double a, double b, double c, double? x1, double? x2)
        {
            bhaskara = new Bhaskara(a, b, c);
            var (raiz1, raiz2) = bhaskara.CalcularRaizes();

            bool iguais = ($"{x1:F3}" == $"{raiz1:F3}") && ($"{x2:F3}" == $"{raiz2:F3}");
            Assert.IsTrue(iguais);
           
        }



    }
}